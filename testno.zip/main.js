collapse=document.querySelector('.collapse').querySelectorAll('a');
console.log(collapse);
collapse.forEach(element => {
    element.addEventListener("click",function(){
        collapse.forEach(nav=>nav.classList.remove('active'))

        this.classList.add('active');
    })
});